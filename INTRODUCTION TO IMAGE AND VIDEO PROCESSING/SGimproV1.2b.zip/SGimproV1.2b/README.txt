
Last update: Oct 5 2009

*** show_pgm_file  () function is changed to be compatible with different C compilers (cl, bcc, gcc, etc.). Otherwise it will only work with gcc.
*** broken web links are fixed in this document

-----------------------------------------------------------

First version:

EE1390/2390 image processing support package 
created by Sevket Gumustekin <sevgum@yahoo.com> Sep 10 1998
 
Files:
-----
cathedral.pgm  
example0.c     
example1.c     
img_pro.c      
img_pro.h      
my_header.h
resample.c
 
This package supports Unix/X-windows and MS-Windows platforms
providing basic functions for handling gray level images.  It is
tested with GNU gcc compiler running on Linux 2.0.30 and GNU
gcc compiler running on Windows NT 4.0. 

MS-Windows port of gcc is available free of charge from:
http://www.cygwin.com/

This package utilizes external image viewers (e.g. popular
image viewer "xv" for Unix/X-Windows (http://www.trilon.com/xv/), 
fast image viewer "Iview32" (www.irfanview.com) for MS-Windows.

Before using this package make sure that you have an image viewer
that is capable of handling pgm format image files in your system. 
Then modify the first few lines of the file "img_pro.h" according 
to your system.

(E.g. if you are using a Unix system with "xv" installed, you should read:
.
.
/* #define MSDOS */
#define UNIX

#ifdef UNIX
#define view "xv -geometry +200+200 " 
#endif
.
. 
 )

Make sure the viewer program is located in one of the directories
that are specified by the environment variable: PATH .
Otherwise you may have to  specify the entire path of the viewer
program in "img_pro.h".

(E.g.
.
#ifdef UNIX
#define view "/usr/X11/bin/xv -geometry +200+200 " 
#endif
.
#ifdef MSDOS
#define view "//c/Program\\ Files/IrfanView/i_view32.exe" 
#endif
.
 )

Compiling:
---------

The package includes two example programs. "example0.c" is a simple
program that utilizes the image handling functions in "img_pro.c".
To compile  "example0.c" type:

        gcc -o example0 example0.c img_pro.c

and to run the program type:

        ./example0
	


A good programming practice involves development of reusable
functions. Once you develop a program for performing a special
task of image processing (e.g. edge detection, thresholding, ...)
you should be able to use it  for more complicated tasks
without worrying about its implementation details.

The function in "resample.c" is provided as a template of a reusable
function. You can modify the header file "my_header.h" to define the 
functions that you develop and plan to reuse. 

The example program "example1.c" uses the resampling function in 
"resample.c". To compile and run this program, type: 

         gcc -o example1 example1.c img_pro.c resample.c -lm
       
       ./example1 [Command line options]


("-lm" is needed to link the program with the math library)


A collection of such functions (func1.c func2.c ...) can be compiled 
together to build a program (foo) from "foo.c" which utilizes these 
functions:

         gcc -o foo foo.c img_pro.c func1.c func2.c ... -lm
	 

To save some compilation time, you can precompile the components
that you plan to reuse:
        
	 gcc -c -o img_pro.o  img_pro.c 
	 gcc -c -o func1.o  func1.c 
	 gcc -c -o func2.o  func2.c 
	 .
	 .
	 .
Then the program can be built by:
 	 
         gcc -o foo foo.c img_pro.o func1.o func2.o ... -lm


Debugging:
---------

It may be a good idea to use the gcc flag "-g" in all the compilation
steps mentioned above. This flag enables debugging run-time errors
using GNU debugger gdb.

To use gdb type:

gdb foo
(gdb) run [Command line options]

This process should pinpoint the instructions that cause the run-time 
errors in the program "foo".



	 











