#include "img_pro.h"

int main()

{
int i,j,NR,NC,NR2,NC2;
unsigned char **img, **img2;

/*---------->>> Start image generation example */
NC=200;
NR=200;
img=alloc_img(NC,NR); /*  allocate image of size: NC cols x NR rows  */

for(i=0;i<NR;i++) 
  for(j=0;j<NC;j++) 
    img[i][j]=j;  /* generate a simple test image  */  

img_to_pgm_file(img,"test.pgm",NC,NR);/*  write to file */
show_pgm_file("test.pgm");/*  show image using an external viewer */
/*----------<<< End image generation example */

/*---------->>> Start image manipulation example */
img2=pgm_file_to_img("cathedral.pgm",&NC2,&NR2);/* read img and its size from file */
for(i=0;i<NR2;i++) 
  for(j=0;j<NC2;j++) 
   if(i<10 || i>NR2-10 || j<10 || j>NC2-10) 
     img2[i][j]=128; /* create a border */

img_to_pgm_file(img2,"test2.pgm",NC2,NR2);/*  write to file */
show_pgm_file("test2.pgm");/*  show image using an external viewer */
/*----------<<< End image manipulation example */

}
