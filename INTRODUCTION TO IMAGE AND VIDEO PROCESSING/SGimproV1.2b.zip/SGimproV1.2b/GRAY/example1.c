#include "img_pro.h"
#include "my_header.h"

int main(int argc, char **argv)

{
unsigned char **img, **img2;
char *pgm_file;
int i,j,k,l,NR,NC,NC2,NR2;

/*---------->>> Start assigning valiables from command line arguments   */
if(argc!=4) {
  printf("\n Usage: example1 [Colsize] [Rowsize] [Image file (*.pgm)] \n");
  printf("\n E.g.   example1 500 500 cathedral.pgm \n");
  exit(-1); }
  
NC=atoi(argv[1]);                /*  Width of image in pixels */
if(NC<0 || NC> 1000) {printf("\n [Colsize] should be between 0 and 1000\n"); exit(0);} 

NR=atoi(argv[2]);                /*  Height of image in pixels */
if(NR<0 || NR> 1000) {printf("\n [Rowsize] should be between 0 and 1000\n"); exit(0);} 

pgm_file=argv[3];
/*----------<<< End assigning valiables from command line arguments  */

/*---------->>> Start image generation example */
img=alloc_img(NC,NR); /*  allocate image of size: NC cols x NR rows  */

k=NR/2; l=NC/2; /*  center location  */
for(i=0;i<NR;i++) 
  for(j=0;j<NC;j++) 
    img[i][j]=255-diagonal((k-i),(l-j));      /* generate a simple test image  */  

img_to_pgm_file(img,"test.pgm",NC,NR);/*  write to file */
show_pgm_file("test.pgm");/*  show image using an external viewer */

/*----------<<< End image generation example */

/*---------->>> Start image manipulation example */
img2=pgm_file_to_img(pgm_file,&NC2,&NR2);/*  read img and its size from file */
show_pgm_file(pgm_file);

img=resample_image(img,NC,NR,NC2,NR2); /* change size of img to match the size of img2 */
for(i=0;i<NR2;i++) 
  for(j=0;j<NC2;j++) 
    img2[i][j]=(img[i][j]+img2[i][j])/2;  /*  Combine two images  */
    
img_to_pgm_file(img2,"test2.pgm",NC2,NR2);
show_pgm_file("test2.pgm");
/*----------<<< End image manipulation example */

free_img(img);
free_img(img2);
/*  if img is not needed anoymore we can free the allocated memory */
/*
.
.
.
*/
return(1);
}

