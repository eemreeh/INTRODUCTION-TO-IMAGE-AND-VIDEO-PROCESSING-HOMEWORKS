unsigned char **resample_image
  (unsigned char **img, int NC, int NR, int NC2, int NR2);
